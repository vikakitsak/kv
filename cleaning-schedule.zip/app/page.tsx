"use client"

import { useEffect, useState } from "react"

export default function CleaningSchedule() {
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({})
  const [isClient, setIsClient] = useState(false)

  const schedule = [
    ["3 травня", "2 кім."],
    ["5 травня", "1 кім."],
    ["7 травня", "2 кім."],
    ["9 травня", "1 кім."],
    ["11 травня", "2 кім."],
    ["13 травня", "1 кім."],
    ["15 травня", "2 кім."],
    ["17 травня", "1 кім."],
    ["19 травня", "2 кім."],
    ["21 травня", "1 кім."],
    ["23 травня", "2 кім."],
    ["25 травня", "1 кім."],
    ["27 травня", "2 кім."],
    ["29 травня", "1 кім."],
    ["31 травня", "2 кім."],
  ]

  // Load saved checkbox states from localStorage on component mount
  useEffect(() => {
    setIsClient(true)
    const savedItems: Record<string, boolean> = {}

    schedule.forEach((_, index) => {
      const key = `cleaning_done_${index}`
      const savedValue = localStorage.getItem(key)
      if (savedValue) {
        savedItems[key] = savedValue === "true"
      }
    })

    setCheckedItems(savedItems)
  }, [])

  // Handle checkbox changes
  const handleCheckboxChange = (index: number, checked: boolean) => {
    const key = `cleaning_done_${index}`
    localStorage.setItem(key, checked.toString())

    setCheckedItems((prev) => ({
      ...prev,
      [key]: checked,
    }))
  }

  return (
    <div className="container">
      <h1>Графік прибирання (травень 2025)</h1>
      <table>
        <thead>
          <tr>
            <th>Дата</th>
            <th>Черга кімнати</th>
            <th>Позначено виконаним</th>
          </tr>
        </thead>
        <tbody>
          {schedule.map(([date, room], index) => {
            const key = `cleaning_done_${index}`
            return (
              <tr key={index}>
                <td>{date}</td>
                <td>{room}</td>
                <td>
                  {isClient && (
                    <input
                      type="checkbox"
                      checked={checkedItems[key] || false}
                      onChange={(e) => handleCheckboxChange(index, e.target.checked)}
                    />
                  )}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
